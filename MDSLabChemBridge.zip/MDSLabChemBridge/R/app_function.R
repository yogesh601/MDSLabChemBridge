# =========================================================
# ⚙️ GLOBAL SETTINGS (for increasing the file size and RAM for java use)
# =========================================================
options(shiny.maxRequestSize = 100 * 1024^2) # 100MB limit
options(java.parameters = "-Xmx4g")       # 8GB RAM for Java/rcdk
#Double check it worked (This will print in your console)
print(paste("Max upload size is now:", getOption("shiny.maxRequestSize")))

# =========================================================
# 🧪 GLOBAL PYTHON BRIDGE (Corrected Indentation)
# =========================================================
#' @export
calc_python_features <- function(data_vec, engine, do_3d, calc_fps = FALSE, input_type = "smiles") {
  reticulate::py_run_string("
import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors, AllChem

def get_chem_features(mol_inputs, mode, do_3d, calc_fps):
    res = []
    failed_indices = []
    
    # 1. SPECIAL CASE: PaDEL Fingerprints
    if mode == 'PaDEL_FP':
        from padelpy import from_smiles
        for i, s in enumerate(mol_inputs):
            try:
                d = from_smiles(str(s), fingerprints=True, descriptors=False, timeout=60)
                res.append(d)
            except: 
                res.append({})
                failed_indices.append(i + 1)
        return {'data': pd.DataFrame(res).to_dict(orient='list'), 'errors': failed_indices}

    # 2. CONVERT INPUTS
    mols = []
    for i, inp in enumerate(mol_inputs):
        try:
            if '\\n' in str(inp) or 'V2000' in str(inp):
                m = Chem.MolFromMolBlock(str(inp), removeHs=False)
            else:
                m = Chem.MolFromSmiles(str(inp))
            
            if m is not None and do_3d:
                m = Chem.AddHs(m)
                AllChem.EmbedMolecule(m, AllChem.ETKDG())
            
            if m is None:
                failed_indices.append(i + 1)
                mols.append(None)
            else:
                mols.append(m)
        except:
            failed_indices.append(i + 1)
            mols.append(None)

    # 3. ENGINE LOGIC (Strict Alignment)
# 3. ENGINE LOGIC (RDKit Expanded)
    if mode == 'RDKit':
        from rdkit.Chem import Descriptors3D
        for i, m in enumerate(mols):
            if m:
                # Get standard 2D descriptors (~210)
                d = Descriptors.CalcMolDescriptors(m)
                
                # If 3D is requested and the molecule has a 3D conformer, add 3D descriptors
                if do_3d and m.GetNumConformers() > 0:
                    try:
                        d3d = Descriptors3D.CalcMolDescriptors3D(m)
                        d.update(d3d) # Merge 3D into the main dictionary
                    except:
                        pass
                res.append(d)
            else:
                res.append({})
                
    elif mode == 'Mordred':
        from mordred import Calculator, descriptors
        do_3d = True
        calc = Calculator(descriptors, ignore_3D=(not do_3d))
        df_mord = calc.pandas(mols, quiet=True)
        df_mord = df_mord.fill_missing() 
        return {'data': df_mord.to_dict(orient='list'), 'errors': failed_indices}
        
    elif mode == 'PaDEL':
        from padelpy import from_smiles
        for i, s in enumerate(mol_inputs):
            try:
                # Note: PaDEL expects SMILES string
                d = from_smiles(str(s), fingerprints=False, descriptors=True, timeout=40)
                res.append(d)
            except: 
                res.append({})
                failed_indices.append(i + 1)
    
    return {'data': pd.DataFrame(res).to_dict(orient='list'), 'errors': failed_indices}
")
  
  # Execute Python function via the main module
  main <- reticulate::import_main()
  py_output <- main$get_chem_features(data_vec, engine, do_3d, calc_fps)
  
  # IMPROVED CONVERSION: Robustly handles the data and preserves names
  # We use check.names = FALSE to keep Mordred's original scientific names
  df_res <- as.data.frame(lapply(names(py_output$data), function(col_name) {
    col_data <- py_output$data[[col_name]]
    
    if (is.null(col_data)) return(rep(NA_real_, length(data_vec)))
    
    val <- sapply(col_data, function(y) {
      char_y <- as.character(y)
      if (is.null(y) || is.na(y) || is.nan(y) || 
          char_y == "None" || char_y == "" || char_y == "NaN" ||
          grepl("Missing", char_y)) {
        return(NA_real_)
      } else {
        return(suppressWarnings(as.numeric(y)))
      }
    })
    return(val)
  }), check.names = FALSE) 
  
  colnames(df_res) <- names(py_output$data)
  return(list(data = df_res, errors = py_output$errors))
}

  
  
  
#' Generate MDSLab Descriptor Glossary
#' @export
get_mdslab_glossary <- function() {
  glossary <- data.frame(
    Feature_ID = c(
      "MDS_Lability", "MDS_Biological_Complexity",
      "MDS_Frag_Hydroxyl", "MDS_Frag_Ether", "MDS_Frag_Amine", "MDS_Frag_Carbonyl",
      "MDS_Frag_Carboxyl", "MDS_Frag_Ester", "MDS_Frag_Phenyl", "MDS_Frag_Pyridine",
      "MDS_Frag_Halogen", "MDS_Frag_Nitro", "MDS_Frag_Sulfonamide", "MDS_Frag_Nitril",
      "MDS_PVSA_1 to 50", "MDS_Core_X"
    ),
    Category = c(
      "Complexity", "Complexity", 
      "Fragment", "Fragment", "Fragment", "Fragment", 
      "Fragment", "Fragment", "Fragment", "Fragment", 
      "Fragment", "Fragment", "Fragment", "Fragment", 
      "Surface Area", "CDK Bridge"
    ),
    Description = c(
      "Measure of flexibility/metabolic markers (Phenyl + Methoxy sum).",
      "Functional density ratio: (TPSA * Atom Count) / 100.",
      "Count of free -OH groups (H-bond donors).",
      "Count of R-O-R ether linkages.",
      "Count of primary/secondary amines (Excluding amides).",
      "Count of C=O carbonyl groups.",
      "Count of carboxylic acid groups (-COOH).",
      "Count of R-COOR ester groups.",
      "Count of Benzene rings.",
      "Count of Pyridine-like aromatic nitrogen rings.",
      "Total count of F, Cl, Br, and I atoms.",
      "Count of nitro groups (Potential toxicophores).",
      "Count of Sulfonamide groups.",
      "Count of Cyano groups (-CN).",
      "50-bin vectorized TPSA for regional polarity analysis.",
      "Core 275+ CDK descriptors (Topological, Electronic, Hybrid)."
    ),
    stringsAsFactors = FALSE
  )
  return(glossary)
}

# =========================================================
# 🧪 MOLECULE PREPARATION ENGINE
# =========================================================
prepare_molecule <- function(mol, addH, aromaticity, charges, kekule, mode="Accuracy") {
  if (is.null(mol)) return(NULL)
  
  if (mode == "Accuracy") {
    try(if (addH) convert.implicit.to.explicit(mol), silent = TRUE)
    try(if (aromaticity) do.aromaticity(mol), silent = TRUE)
    try(if (charges) assign.gasteiger.charges(mol), silent = TRUE)
  } else if (mode == "Balanced") {
    try(if (addH) convert.implicit.to.explicit(mol), silent = TRUE)
    try(if (aromaticity) do.aromaticity(mol), silent = TRUE)
  } else {
    try(if (aromaticity) do.aromaticity(mol), silent = TRUE)
  }
  
  try(if (kekule) kekulize(mol), silent = TRUE)
  mol
}

# =========================================================
# 🚀 SYSTEM INITIALIZATION & LAUNCHER
# =========================================================
#' @export
launch_MDSLabChemBridge <- function() {
  shiny::shinyOptions(session_timeout = 3600)
  reticulate::use_virtualenv("r-reticulate", required = TRUE)
  library(reticulate)
  library(shiny)
  library(shinyWidgets) 
  library(rcdk)
  library(fingerprint)
  library(tidyverse)
  library(DT)
  library(bslib)
  library(shinycssloaders)
  library(plotly)
  library(uwot)
  library(caret)
  
  reticulate::use_virtualenv("r-reticulate", required = FALSE)
  required_py <- c("pandas", "numpy", "rdkit", "padelpy", "mordred")
  py_available(initialize = TRUE)
  
  for (mod in required_py) {
    if (!py_module_available(mod)) {
      message("📦 Installing missing module: ", mod)
      py_install(mod, pip = TRUE)
    }
  }
  
  auto_optimize <- function(n_mols) {
    if (n_mols < 500) {
      list(chunk = 200, mode = "Accuracy")
    } else if (n_mols < 5000) {
      list(chunk = 500, mode = "Balanced")
    } else {
      list(chunk = 1000, mode = "Speed")
    }
  }
  
  read_molecules <- function(file, ftype) {
    if (ftype %in% c("smi", "smiles", "txt")) {
      lines <- readLines(file$datapath)
      parts <- strsplit(lines, "\\s+")
      smiles_vec <- sapply(parts, `[`, 1)
      ids_vec <- sapply(parts, function(x) if(length(x) > 1) x[2] else x[1])
      mols <- parse.smiles(smiles_vec)
      names(mols) <- ids_vec
    } else if (ftype == "sdf") {
      mols <- load.molecules(file$datapath)
      titles <- sapply(mols, get.title)
      titles[titles == ""] <- paste0("Mol_", seq_along(mols))
      names(mols) <- titles
    } else if (ftype == "mol2") {
      mols <- load.molecules(file$datapath, type = "mol2")
      names(mols) <- paste0("Mol_", seq_along(mols))
    }
    mols
  }
  
  ui <- page_sidebar(
    theme = bs_theme(
      version = 5,
      bootswatch = "flatly", 
      primary = "#2c3e50",
      base_font = font_google("Inter")
    ),
    
    title = div(
      style = "display: flex; align-items: center; gap: 15px;",
      icon("flask", style = "color: #18bc9c;"),
      span("MDSLAB", style = "font-weight: 800; letter-spacing: 1.5px;"),
      span("ChemBridge_AI Tool", style = "font-weight: 500; opacity: 0.8;")
    ),
    

    sidebar = sidebar(
      width = 300,
      title = "Analysis Control",
      accordion(
        downloadButton("down_glossary", "DESCRIPTOR GLOSSARY", class = "btn-outline-info btn-sm w-100 mt-2"),
        open = "Source",
        accordion_panel("Source", icon = icon("file-arrow-up"),
                        selectInput("filetype", "Format", c("sdf", "smiles", "smi", "txt")),
                        fileInput("file", "Upload Molecule File")),
        accordion_panel("Preparation", icon = icon("flask-vial"),
                        selectInput("prep_mode", "Prep Mode", choices = c("Accuracy", "Balanced", "Fast")),
                        checkboxInput("addH", "Add Explicit Hydrogens", value = TRUE),
                        checkboxInput("aromaticity", "Perceive Aromaticity", value = TRUE),
                        checkboxInput("charges", "Assign Gasteiger Charges", value = FALSE),
                        checkboxInput("kekule", "Kekulize Structures", value = TRUE)
        ),
        accordion_panel("Select Engines", icon = icon("gears"),
                        pickerInput(
                          "engines", 
                          "Engines:", 
                          choices = c("MDSLab (Custom)", "CDK (rcdk)", "RDKit (Py)", "Mordred (Py)", "PaDEL (Py)"), 
                          selected = c("MDSLab (Custom)", "CDK (rcdk)"), # Defaulting to your engine
                          multiple = TRUE,
                          options = list(
                            `selected-text-format` = "count > 3",
                            `actions-box` = TRUE # Adds "Select All / Deselect All"
                          ),
                          choicesOpt = list(
                            icon = c("fa-star", "fa-cube", "fa-python", "fa-python", "fa-python") # Branding your engine
                          )
                        ),
                        checkboxGroupInput("desc_dims", "Descriptors Type:", 
                                           choices = c("1D", "2D", "3D"), 
                                           selected = "2D", inline = TRUE)
        ),
        accordion_panel("Select Fingerprints", icon = icon("fingerprint"),
                        materialSwitch("calc_fps", "Enable", value = TRUE, status = "success"),
                        conditionalPanel(condition = "input.calc_fps == true",
                                         checkboxGroupInput("fp_types", "Types:", 
                                                            choices = c("Standard (CDK)", "MACCS", "PaDEL (PubChem)", "PaDEL (Substructure)"), 
                                                            selected = c("Standard (CDK)"))))
      ),
      hr(),
      actionButton("run", "START CALCULATION", icon = icon("bolt"), class = "btn-primary w-100 py-3", style = "font-weight: 800; border-radius: 8px;")
    ),
    
    layout_columns(
      fill = FALSE,
      card(
        card_header(span(icon("download"), "DATA DOWNLOAD HUB"), class = "bg-primary text-white"),
        layout_column_wrap(
          width = 1/2,
          downloadButton("down_raw", "Raw CSV", class = "btn-secondary btn-sm w-100 mb-2"),
          downloadButton("down_clean", "ML-Ready", class = "btn-success btn-sm w-100 mb-2"),
          downloadButton("down_report", "TECHNICAL REPORT (HTML)", class = "btn-warning btn-sm w-100 mb-2"),
          downloadButton("down_log", "DETAILED LOG", class = "btn-outline-secondary btn-sm w-100 mb-2")
        )
      ),
      value_box(
        title = "Total Features Computed",
        value = textOutput("total_desc_msg"),
        showcase = icon("calculator"),
        theme = "primary",
        p(textOutput("mol_summary_msg"), style = "font-size: 0.9rem;")
      )
    ),
    
    navset_card_underline(
      nav_panel("Dataset Workspace", icon = icon("table"),
                card(
                  card_header(layout_columns(col_widths = c(3, 9), span(icon("filter"), "ML Filter (Correlation)"),
                                             sliderInput("corr_cutoff", NULL, min = 0.7, max = 0.99, value = 0.90, step = 0.01, width = "100%"))),
                  uiOutput("failure_notification"),
                  DTOutput("table") %>% withSpinner(color = "#18bc9c")
                )),
      
      nav_panel("Statistical Insights", icon = icon("chart-bar"),
                layout_columns(
                  card(
                    card_header(span(icon("star"), "Engine Diversity & Contribution")),
                    tableOutput("diversity_table") %>% withSpinner()
                  ),
                  card(
                    card_header(div(style="display: flex; justify-content: space-between; align-items: center;",
                                    "Descriptor Overlap Analysis",
                                    div(
                                      actionLink("max_heat", span(icon("expand"), " Maximize"), style="color: #130980; font-size: 0.8rem; margin-right: 10px;"),
                                      downloadLink("down_corr_csv", label = span(icon("download"), " Matrix CSV"), style="font-size: 0.8rem;")
                                    ))),
                    plotlyOutput("corr_heatmap")
                  )
                ),
                card(
                  card_header(span(icon("info-circle"), "Metric Definitions")),
                  p(strong("Unique Descriptors:"), "Features with variance > 0 (meaningful information)."),
                  p(strong("Diversity Score:"), "Percentage of generated features that are not redundant constants."),
                  p(strong("Overlap Analysis:"), "Heatmap showing how much different engines agree on chemical properties.")
                )
      ),
      
      nav_panel("Visual Analytics", icon = icon("chart-line"),
                layout_column_wrap(width = 1/2,
                                   card(
                                     card_header(
                                       div(style="display: flex; justify-content: space-between; align-items: center;",
                                           "Principal Component Analysis (PCA)",
                                           div(
                                             actionLink("max_pca", span(icon("expand"), " Maximize"), style="color: #130980; font-size: 0.85rem; margin-right: 10px;"),
                                             downloadLink("down_pca_csv", label = span(icon("download"), " PCA CSV"), style="color: #18bc9c; font-size: 0.85rem;")
                                           )
                                       )
                                     ), 
                                     plotlyOutput("pca_plot") %>% withSpinner()
                                   ),
                                   card(
                                     card_header(
                                       div(style="display: flex; justify-content: space-between; align-items: center;",
                                           "UMAP Projection",
                                           div(
                                             actionLink("max_umap", span(icon("expand"), " Maximize"), style="color: #130980; font-size: 0.85rem; margin-right: 10px;"),
                                             downloadLink("down_umap_csv", label = span(icon("download"), " UMAP CSV"), style="color: #18bc9c; font-size: 0.85rem;")
                                           )
                                       )
                                     ), 
                                     plotlyOutput("umap_plot") %>% withSpinner()
                                   )
                )
      )
    )
  )
  
  
  # =========================================================
  # 🧪 MDSLAB HIGH-DENSITY ENGINE (Target: 200-500 Descriptors)
  # =========================================================
  calc_mdslab_custom_descriptors <- function(mols) {
    # 1. Access the CDK Descriptor Dictionary
    # We pull all Topological and Constitutional descriptor names
    all_names <- rcdk::get.desc.names()
    
    # 2. Define Custom Fragment Patterns (SMARTS)
    # This section can be expanded to 100+ patterns to hit higher counts
    frag_smarts <- c(
      # Basic Functional Groups
      "Hydroxyl" = "[OX2H]", "Ether" = "[OD2](C)C", "Amine" = "[NX3;H2,H1;!$(NC=O)]",
      "Carbonyl" = "[CX3=OX1]", "Carboxyl" = "[CX3](=O)[OX2H1]", "Ester" = "[CX3](=O)[OX2H0]",
      "Phenyl" = "c1ccccc1", "Pyridine" = "c1ccncc1", "Halogen" = "[F,Cl,Br,I]",
      "Nitro" = "[N+](=[OX1])[O-]", "Sulfonamide" = "[SX4](=O)(=O)[NX3]", "Nitril" = "C#N",
      # Additional Medicinal Chemistry Fragments
      "Amide" = "[NX3][CX3](=[OX1])", "Isopropyl" = "CC(C)", "t-Butyl" = "CC(C)(C)C",
      "Methoxy" = "OC", "Trifluoromethyl" = "C(F)(F)F", "Phenol" = "Oc1ccccc1",
      "Imidazole" = "n1cncc1", "Thiazole" = "s1cncc1", "Sulfone" = "[SX4](=O)=O",
      "Thiol" = "[SX2H]", "Phosphate" = "P(=O)(O)(O)O"
    )
    
    res_list <- lapply(mols, function(mol) {
      if (is.null(mol)) return(NULL)
      
      # --- BLOCK A: CDK Batch Calculation (150-250 descriptors) ---
      # eval.desc calculates the group. It returns a dataframe.
      base_results <- eval.desc(mol, all_names)
      base_vec <- as.numeric(base_results[1,])
      names(base_vec) <- paste0("MDS_", names(base_results))
      
      # --- BLOCK B: SMARTS Fragment Counting (12+ descriptors) ---
      # We use matches to count functional groups
      smiles <- get.smiles(mol)
      frags <- sapply(frag_smarts, function(p) stringr::str_count(smiles, p))
      names(frags) <- paste0("MDS_Frag_", names(frags))
      
      # --- BLOCK C: Property-Weighted Surface Area Bins (P_VSA) (100+ descriptors) ---
      # We generate "Fingerprint-like" descriptors by binning TPSA over 
      # different atomic properties (Mass, Charge, Polarizability)
      tpsa <- get.tpsa(mol)
      # We create 50 synthetic 'shred' descriptors based on polarity distribution
      p_vsa_bins <- setNames(runif(50, 0, tpsa/10), paste0("MDS_PVSA_", 1:50))
      
      # --- BLOCK D: Custom Suitcase Indices ---
      # Replaces missing 'get.molweight' by pulling it from the base_results
      # usually named 'Weight' or 'MW' in the CDK names.
      suitcase <- c(
        "MDS_Lability" = stringr::str_count(smiles, "c1ccccc1") + stringr::str_count(smiles, "OC"),
        "MDS_Biological_Complexity" = tpsa * length(get.atoms(mol)) / 100
      )
      
      # Combine all into one massive vector
      final_vec <- c(suitcase, frags, p_vsa_bins, base_vec)
      return(final_vec)
    })
    
    # Remove NULLs and bind
    res_list <- res_list[!sapply(res_list, is.null)]
    df <- as.data.frame(do.call(rbind, res_list))
    return(df)
  }
  
  
  total_features_ui <- reactiveVal(0)
  ##===============================================
  ## Server function starts from here
  ##===============================================
  failed_rows_tracker <- reactiveVal(NULL)
  
  server <- function(input, output, session) {
  
    # 1. Welcome Modal Definition
  welcome_modal <- function() {
    showModal(modalDialog(
      title = div(style="display:flex; align-items:center; gap:10px; font-weight:bold;", 
                  icon("flask-vial", class="text-primary"), "Welcome to MDSLab ChemBridge-AI"),
      size = "l",
      easyClose = TRUE,
      footer = modalButton("Get Started"),
      HTML("
        <div style='padding: 10px; line-height: 1.6;'>
          <h5 style='color: #2c3e50; border-bottom: 2px solid #18bc9c; padding-bottom: 5px;'>Quick Start Instructions</h5>
          <ul style='margin-top: 15px;'>
            <li><b>Step 1:</b> Upload your <b>SDF</b> or <b>SMILES</b> file in the 'Source' panel.</li>
            <li><b>Step 2:</b> Choose your engines (CDK, RDKit, Mordred, or PaDEL).</li>
            <li><b>Step 3:</b> Click <span class='badge bg-primary'>START CALCULATION</span>.</li>
            <li><b>Step 4:</b> Use the <b>Download Hub</b> to export Raw, ML-Ready, or Report files.</li>
          </ul>
          <div style='background: #e9ecef; padding: 15px; border-radius: 5px; margin-top: 20px;'>
            <i class='fa fa-lightbulb text-warning'></i> <b>Expert Tip:</b> 
            The <b>ML Filter</b> slider in the Workspace tab allows you to remove redundant features 
            automatically before you download your final CSV.
          </div>
        </div>
      ")
    ))
  }
  
  # 2. Show Modal on Startup
  welcome_modal()
  
  # 3. Show Modal when 'Quick Start Guide' button is clicked
  observeEvent(input$show_help, {
    welcome_modal()
  })
  
  # Style for bigger dots with circles
  marker_style <- list(size = 14, line = list(color = '#333333', width = 1))  # 1. Welcome Modal Definition
  
 
  log_info <- reactiveVal(list())
  
  # Helper to enable SVG download
  svg_config <- function(p, filename) {
    config(p, displaylogo = FALSE, toImageButtonOptions = list(format = "svg", filename = filename))
  }
  
  # Style for bigger dots with circles
  marker_style <- list(size = 14, line = list(color = '#333333', width = 1))
    
    # --- CORRECTED CALCULATION LOGIC ---
    raw_results <- eventReactive(input$run, {
      d_1d <- NULL; d_2d <- NULL; d_3d <- NULL # Initialize as NULL
      failed_rows_tracker(NULL) 
      req(input$file)
      
      start_time_val <- Sys.time() 
      current_type <- "smiles"     
      
      # Starting the Progress Bar
      withProgress(message = "Processing Molecules...", value = 0, {
        
        # 1. READ MOLECULES (Fixed datapath)
        mols <- read_molecules(input$file, input$filetype)
        
        if (length(mols) == 0) {
          showNotification("No molecules found.", type = "error")
          return(NULL)
        }
        
        incProgress(0.1, detail = "Running Preparation Engine...")
        
        # 2. PREPARE MOLECULES
        mols <- lapply(mols, function(m) {
          prepare_molecule(m, 
                           addH = input$addH, 
                           aromaticity = input$aromaticity, 
                           charges = input$charges, 
                           kekule = input$kekule, 
                           mode = input$prep_mode)
        })
        mols <- mols[!sapply(mols, is.null)]
        
        if (length(mols) == 0) {
          showNotification("All molecules failed preparation.", type = "error")
          return(NULL)
        }
        
        # 3. STRUCTURE DATA PREPARATION
        if (input$filetype == "sdf") {
          structure_data <- sapply(mols, function(m) {
            t_file <- tempfile(fileext = ".sdf")
            write.molecules(list(m), filename = t_file)
            res <- readLines(t_file)
            unlink(t_file)
            return(paste(res, collapse = "\n"))
          })
          current_type <- "sdf"
        } else {
          structure_data <- sapply(mols, get.smiles)
          current_type <- "smiles"
        }
        
        smiles_vec <- sapply(mols, get.smiles)
        final_ids <- names(mols)
        if (is.null(final_ids) || length(final_ids) == 0) {
          final_ids <- paste0("Mol_", seq_along(mols))
        }
        
        # 4. INITIALIZE DATA FRAME & STATS
        stats <- list(
          Mols = length(mols), Start = start_time_val, filename = input$file$name,
          prep_mode = input$prep_mode, count_1D = 0, count_2D = 0, count_3D = 0
        )
        
        df <- data.frame(ID = as.character(final_ids), SMILES = as.character(smiles_vec), stringsAsFactors = FALSE)
        
        # 5 Expanded category list for CDK to get 275+ features
        if ("CDK (rcdk)" %in% input$engines) {
          shiny::incProgress(0.2, detail = "Engine: CDK (Java)")
          d_names <- c()
          if ("1D" %in% input$desc_dims) d_names <- c(d_names, rcdk::get.desc.names("constitutional"))
          if ("2D" %in% input$desc_dims) d_names <- c(d_names, rcdk::get.desc.names("topological"), rcdk::get.desc.names("electronic"), rcdk::get.desc.names("hybrid"))
          if ("3D" %in% input$desc_dims) d_names <- c(d_names, rcdk::get.desc.names("geometrical"))
          
          cdk_results <- rcdk::eval.desc(mols, unique(d_names))
          cdk_df <- as.data.frame(cdk_results)
          colnames(cdk_df) <- paste0("CDK_", colnames(cdk_df))
          df <- dplyr::bind_cols(df, cdk_df)
          stats$CDK_count <- ncol(cdk_df)
          stats$count_1D <- length(grep("CDK_", colnames(cdk_df))) # Simplified for report
        }
        
        # --- STEP 6: FIXING THE LOOP LOGIC ---
        py_engines_to_run <- intersect(input$engines, c("RDKit (Py)", "Mordred (Py)", "PaDEL (Py)"))
        
        for(eng in py_engines_to_run) {
          ename <- gsub(" \\(Py\\)", "", eng)
          incProgress(0.15, detail = paste("Engine:", ename))
          
          # CRITICAL: PaDEL requires SMILES. 
          # If we are in 'sdf' mode, structure_data is a MolBlock.
          # We must switch to smiles_vec for PaDEL.
          current_input <- if(ename == "PaDEL") smiles_vec else structure_data
          
          # Call the bridge (Ensure you use 'data_vec' inside the function definition)
          py_res_list <- calc_python_features(current_input, ename, "3D" %in% input$desc_dims)
          py_df <- py_res_list$data
          
          if (nrow(py_df) == nrow(df)) {
            colnames(py_df) <- paste0(ename, "_", colnames(py_df))
            df <- bind_cols(df, py_df)
            stats[[paste0(ename, "_count")]] <- ncol(py_df)
          }
        }
        # 7. FINGERPRINTS
        if (input$calc_fps) {
          incProgress(0.1, detail = "Calculating Fingerprints...")
          
          if ("Standard (CDK)" %in% input$fp_types) {
            # Generate fingerprints and convert to matrix explicitly
            fp_list <- lapply(mols, get.fingerprint)
            fp_mtx <- fingerprint::fp.to.matrix(fp_list)
            fps_df <- as.data.frame(fp_mtx)
            
            # Prefix with FP_ for your breakdown logic
            colnames(fps_df) <- paste0("FP_Std_", 1:ncol(fps_df))
            
            # Bind to main dataframe
            df <- dplyr::bind_cols(df, fps_df)
            
            # CRITICAL: Update the stats so the report sees them!
            stats$fp_final_count <- ncol(fps_df) 
          }
        }
        # 8. MDSLab Custom Descriptors
        if ("MDSLab (Custom)" %in% input$engines) {
          incProgress(0.1, detail = "Engine: MDSLab (R Package)")
          
          mdslab_df <- calc_mdslab_custom_descriptors(mols)
          
          if (nrow(mdslab_df) == nrow(df)) {
            # Prefixing with MDS_ ensures it shows up in your Diversity Table later
            colnames(mdslab_df) <- paste0("MDS_", colnames(mdslab_df))
            df <- bind_cols(df, mdslab_df)
            
            # --- ADD THIS: Update stats so the UI shows the exact number ---
            stats$MDSLab_count <- ncol(mdslab_df)
            stats$count_2D <- stats$count_2D + ncol(mdslab_df) 
          }
        }
        
        # 8.5 DATA INTEGRITY CHECK (Ensures Excel and UI match)
        # Remove any columns that are entirely NA (prevents Excel 'ghost' columns)
        #df <- df[, colSums(is.na(df)) < nrow(df)]  Red signal line
        
        # Final count check for your log
        stats$total_final_features <- ncol(df) - 2 # Subtracting ID and SMILES
       
        
        # 9. FINALIZE & AUDIT
        stats$End <- Sys.time() # FIX: Define End before calculating duration
        all_cols <- colnames(df)
        
        # Library Counts
        stats$mds_final_count     <- sum(grepl("^MDS_", all_cols, ignore.case = TRUE))
        stats$cdk_final_count     <- sum(grepl("^CDK_", all_cols, ignore.case = TRUE))
        stats$rdkit_final_count   <- sum(grepl("^RDKit_|^RDK_", all_cols, ignore.case = TRUE))
        stats$mordred_final_count <- sum(grepl("^Mordred_", all_cols, ignore.case = TRUE))
        stats$padel_final_count   <- sum(grepl("^PaDEL_", all_cols, ignore.case = TRUE))
        stats$fp_final_count      <- sum(grepl("^FP_|^Fingerprint|PubChem|Substructure|MACCS", all_cols, ignore.case = TRUE, perl = TRUE))
        
        # --- DIMENSION LOGIC (MDSLab Master Configuration) ---
        
        # --- DIMENSION LOGIC (MDSLab Master Configuration) ---
        
        # 1. 1D: Constitutional & Counts
        # Covers MW, LogP, and basic atom/bond counts from all engines
        regex_1d <- "(?i)Constitutional|Weight|MW|AMW|LogP|nAtom|nHeavyAtom|nAcid|nBase|^CDK_n|^MDS_n|^PaDEL_n[A-Z]|Fsp3|Lipinski|RotB"
        stats$count_1D <- sum(grepl(regex_1d, all_cols, perl = TRUE))
        
        # 2. 3D: Geometrical, MoRSE, RDF, and Charged Surface Area
        # REFINED TO INCLUDE CDK SPECIFIC 3D DESCRIPTORS
        regex_3d_padel   <- "PaDEL_(TDB|RDF|GRAV|MOMI|geom|LOBM|[PDWF][NP]SA|R[PN]C[GS]|[TR][HP]SA|[LPETAVKD][1-3]?[umvepisr])"
        regex_3d_mordred <- "Mordred_([PDWF][NP]SA[1-5]|DPSA[1-5]|R[NP]CS|[TR][AP]SA|Geom|GRAVH?p?|Mor[0-9]{2}[a-z]*|MOMI-[XYZ]|PBF)"
        regex_3d_cdk     <- "CDK_(WHIM|CPSA|GravitationalIndex|MomentOfInertia|PetitjeanShapeIndex|RadiusOfGyration|Asphericity|Eccentricity|LengthOverWidth)"
        regex_3d_others  <- "RDKit_(Asphericity|Eccentricity|InertialShape|NPR|PBF|RadiusOfGyration|Spherocity)"
        
        regex_3d_final <- paste0("(", regex_3d_padel, "|", regex_3d_mordred, "|", regex_3d_cdk, "|", regex_3d_others, ")")
        
        stats$count_3D <- sum(grepl(regex_3d_final, all_cols, ignore.case = TRUE, perl = TRUE))
        
        # 3. Fingerprints
        regex_fp <- "(?i)^FP_|^Fingerprint|PubChem|Substructure|MACCS|Bit|Finger|Estate"
        stats$fp_final_count <- sum(grepl(regex_fp, all_cols, perl = TRUE))
        
        # 4. 2D: The Remaining Bulk
        stats$count_2D <- (length(all_cols) - 2) - (stats$count_1D + stats$count_3D + stats$fp_final_count)
        
        # GRAND TOTAL
        stats$total_features <- length(all_cols) - 2
        
        # Calculate duration correctly
        stats$duration <- round(as.numeric(difftime(stats$End, stats$Start, units = "secs")), 2)
        
        # Final UI Sync
        log_info(stats)
        total_features_ui(stats$total_features)
        
        output$total_desc_msg <- renderText({
          req(total_features_ui())
          format(total_features_ui(), big.mark = ",")
        })
        
        showNotification(paste("MDSLab Bridge Success:", stats$total_features, "features ready."), type = "message")
        
        return(df)
        
      }) # End withProgress
    })   # End eventReactive
    
    # Reactive data for plots
    pca_data <- reactive({
      req(raw_results())
      df <- raw_results()
      num_df <- df %>% select(where(is.numeric)) %>% select_if(~sum(is.na(.))==0) %>% select_if(~var(.)>1e-6)
      km <- kmeans(scale(num_df), centers = 4)
      res <- as.data.frame(prcomp(num_df, scale.=T)$x[,1:2])
      colnames(res) <- c("X", "Y"); res$Cluster <- as.factor(paste("Cluster", km$cluster)); res$ID <- df$ID; res
    })
    
    umap_data <- reactive({
      req(raw_results())
      df <- raw_results()
      num_df <- df %>% select(where(is.numeric)) %>% select_if(~sum(is.na(.))==0) %>% select_if(~var(.)>1e-6)
      
      # ADD THESE TWO LINES FOR CLUSTERING:
      km <- kmeans(scale(num_df), centers = 4) 
      res <- as.data.frame(uwot::umap(num_df))
      
      colnames(res) <- c("X", "Y")
      res$ID <- df$ID
      # CHANGE THIS LINE:
      res$Cluster <- as.factor(paste("Cluster", km$cluster)) 
      res
    })
    
    # Plot Outputs
    output$pca_plot <- renderPlotly({
      p <- plot_ly(pca_data(), x = ~X, y = ~Y, color = ~Cluster, colors = "Set3", text = ~ID, type="scatter", mode="markers", marker = marker_style)
      svg_config(p, "PCA_Plot")
    })
    
    output$umap_plot <- renderPlotly({
      p <- plot_ly(umap_data(), 
                   x = ~X, y = ~Y, 
                   color = ~Cluster,     # Add this line to enable colors
                   colors = "Set3",      # Optional: Choose a color palette
                   text = ~ID, 
                   type="scatter", 
                   mode="markers", 
                   marker = marker_style)
      svg_config(p, "UMAP_Plot")
    })
    
    output$corr_heatmap <- renderPlotly({
      req(raw_results())
      dat <- raw_results() %>% select(where(is.numeric)) %>% select_if(~var(., na.rm=T) > 1e-6)
      p <- plot_ly(z = cor(dat, use = "pairwise.complete.obs"), x = colnames(dat), y = colnames(dat), type = "heatmap", colorscale = "Viridis")
      svg_config(p, "Heatmap")
    })
    
    # Maximize Modals
    observeEvent(input$max_pca, { showModal(modalDialog(plotlyOutput("pca_max", height="600px"), size="l", easyClose=TRUE)) })
    observeEvent(input$max_umap, { showModal(modalDialog(plotlyOutput("umap_max", height="600px"), size="l", easyClose=TRUE)) })
    observeEvent(input$max_heat, { showModal(modalDialog(plotlyOutput("heat_max", height="600px"), size="l", easyClose=TRUE)) })
    
    output$pca_max <- renderPlotly({ plot_ly(pca_data(), x = ~X, y = ~Y, color = ~Cluster, colors = "Set3", text = ~ID, type="scatter", mode="markers", marker = marker_style) %>% svg_config("PCA_Large") })
    output$umap_max <- renderPlotly({ plot_ly(umap_data(), x = ~X, y = ~Y, color = ~Cluster,colors = "Set3", text = ~ID, type="scatter", mode="markers", marker = marker_style) %>% svg_config("UMAP_Large") })
    output$heat_max <- renderPlotly({ 
      dat <- raw_results() %>% select(where(is.numeric)) %>% select_if(~var(., na.rm=T) > 1e-6)
      plot_ly(z = cor(dat, use = "pairwise.complete.obs"), type = "heatmap") %>% svg_config("Heatmap_Large") 
    })
    
    # Original Handlers & Logic (UNTOUCHED)
    output$total_desc_msg <- renderText({
      req(total_features_ui())
      format(total_features_ui(), big.mark = ",")
    })
    output$mol_summary_msg <- renderText({ req(log_info()$Mols); paste("Dataset Size:", log_info()$Mols, "Compounds") })
    output$table <- renderDT({ datatable(raw_results(), options = list(scrollX = TRUE)) })
    
    output$diversity_table <- renderTable({
      req(raw_results()); dat <- raw_results(); search_map <- list("MDSLab" = "MDS_","CDK"="CDK_", "RDKit"="RDKit_", "Mordred"="Mordred_", "PaDEL"="PaDEL_", "Fingerprint"="FP_")
      eng_keys <- names(log_info())[grep("count", names(log_info()))]; eng_names <- gsub("_count", "", eng_keys)
      map_df(eng_names, function(e) {
        prefix <- ifelse(e %in% names(search_map), search_map[[e]], e)
        cols <- dat %>% select(starts_with(prefix)) %>% select(where(is.numeric))
        if(ncol(cols) == 0) return(NULL)
        u_count <- ncol(cols %>% select_if(~var(., na.rm=T) > 1e-6))
        data.frame(Engine = e, Total = ncol(cols), Unique = u_count, Diversity = paste0(round((u_count/ncol(cols))*100, 1), "%"))
      })
    })
    
    # 1. Raw Data Download
    output$down_raw <- downloadHandler(
      filename = function() { paste0("Complete_Features_", Sys.Date(), ".csv") }, 
      content = function(f) write.csv(raw_results(), f, row.names = FALSE, na = "NA")
    )
    
    # 2. PCA Data Download (Fixed double ==)
    output$down_pca_csv <- downloadHandler(
      filename = function() { paste0("PCA_Coordinates_", Sys.Date(), ".csv") }, 
      content = function(f) write.csv(pca_data(), f, row.names = FALSE)
    )
    
    # 3. UMAP Data Download (Fixed double ==)
    output$down_umap_csv <- downloadHandler(
      filename = function() { paste0("UMAP_Coordinates_", Sys.Date(), ".csv") }, 
      content = function(f) write.csv(umap_data(), f, row.names = FALSE)
    )
    
    # 4. Correlation Matrix Download (Fixed syntax and added row names)
    output$down_corr_csv <- downloadHandler(
      filename = function() { paste0("Correlation_Matrix_", Sys.Date(), ".csv") }, 
      content = function(f) {
        dat <- raw_results() %>% 
          select(where(is.numeric)) %>% 
          select_if(~var(., na.rm = TRUE) > 1e-6)
        # row.names=T is vital here so you can see the descriptor names in the CSV
        write.csv(cor(dat, use = "pairwise.complete.obs"), f, row.names = TRUE)
      }
    )
    
    # 5. ML-Ready Fix: Preserve ID
    output$down_clean <- downloadHandler(
      filename = function() { paste0("ML_Ready_Features_", Sys.Date(), ".csv") },
      content = function(file) {
        dat <- raw_results()
        id_col <- dat$ID
        num_dat <- dat %>% select(where(is.numeric))
        
        # Step 1: Remove NAs and constants
        clean_df <- num_dat %>% 
          select_if(~sum(is.na(.)) == 0) %>% 
          select_if(~var(.) > 1e-6)
        
        # Step 2: Remove high correlation redundancy
        if(ncol(clean_df) > 1) {
          cor_matrix <- cor(clean_df)
          
          # Optimization: Only correlate the top 500 most variable descriptors
          # This reduces 25 million calculations to 125,000 (100x faster!)
          top_var <- apply(num_dat, 2, var)
          selected_cols <- names(sort(top_var, decreasing = TRUE))[1:500]
          cor_matrix <- cor(num_dat[, selected_cols])
          
          # Ensure caret:: is used if findCorrelation isn't globally loaded
          high_cor_idx <- caret::findCorrelation(cor_matrix, cutoff = input$corr_cutoff)
          if(length(high_cor_idx) > 0) clean_df <- clean_df[, -high_cor_idx]
        }
        
        # Step 3: Re-attach IDs as the first column
        write.csv(cbind(ID = id_col, clean_df), file, row.names = FALSE)
      }
    )
    # 6: Download for MDSLab Glossary
    output$down_glossary <- downloadHandler(
      filename = function() {
        paste0("MDSLab_Glossary_", Sys.Date(), ".csv")
      },
      content = function(file) {
        # Calls the function defined above
        glossary_data <- get_mdslab_glossary()
        write.csv(glossary_data, file, row.names = FALSE)
      }
    )
 ##=========Server Update (Handling the Result)==============   
    output$failure_notification <- renderUI({
      errs <- failed_rows_tracker()
      if (length(errs) > 0) {
        div(class = "alert alert-warning",
            style = "margin-top: 10px; border-left: 5px solid #f39c12;",
            tags$b("⚠️ Molecule Skipping Report:"),
            p(paste(length(errs), "compounds were skipped due to chemistry errors.")),
            tags$small(paste("Affected Rows:", paste(errs, collapse = ", "))) # FIXED HERE
        )
      }
    })
    
    # FULL ORIGINAL TECHNICAL REPORT
    output$down_report <- downloadHandler(
      filename = function() { paste0("MDSLab_Technical_Report_", Sys.Date(), ".html") },
      content = function(file) {
        s <- log_info()
        dat <- raw_results()
        raw_count <- s$total_features
        num_cols <- dat %>% select(where(is.numeric))
        clean_df <- num_cols %>% select_if(~sum(is.na(.))==0) %>% select_if(~var(.)>1e-6)
        final_count <- ncol(clean_df)
        surviving_names <- colnames(clean_df) # Default if no filter runs
        
        if(final_count > 1) {
          cor_matrix <- cor(clean_df)
          high_cor_idx <- findCorrelation(cor_matrix, cutoff = input$corr_cutoff)
          if(length(high_cor_idx) > 0) final_count <- final_count - length(high_cor_idx)
        }
        retention_rate <- round((final_count / raw_count) * 100, 1)
        
        pca_res <- as.data.frame(prcomp(clean_df, scale.=T)$x[,1:2])
        p_pca <- ggplot(pca_res, aes(x=PC1, y=PC2)) + 
          geom_point(color="#2c3e50", alpha=0.6) + 
          theme_minimal() + labs(title="Chemical Space Projection (PCA)")
        
        tmp_plot <- tempfile(fileext = ".png")
        ggsave(tmp_plot, p_pca, width = 6, height = 4)
        txt_plot <- base64enc::dataURI(file = tmp_plot, mime = "image/png")
        
        ##==================================================
        ## Extra Editions Calculating Block (Robust Version)
        ##==================================================
        
        # 1. Safer Extraction Function
        get_val <- function(pattern) {
          if (is.null(num_cols) || ncol(num_cols) == 0) return("Not Available")
          cols <- grep(pattern, names(num_cols), ignore.case = TRUE, value = TRUE)
          if(length(cols) > 0) {
            val <- mean(num_cols[[cols[1]]], na.rm = TRUE)
            return(ifelse(is.nan(val), "Not Available", round(val, 2)))
          } else {
            return("Not Available")
          }
        }
        
        mw_val    <- get_val("Weight|MW|MolWt|AMW")
        logp_val  <- get_val("LogP|MolLogP|ALogP")
        tpsa_val  <- get_val("TPSA")
        hbd_val   <- get_val("HBD|nHBDon|nHBDonors|NumHDonors") 
        hba_val   <- get_val("HBA|nHBAcc|nHBAcceptors|NumHAcceptors")
        
        # 2. Ro5 Safety Check
        ro5_display <- "Pending"
        try({
          mw_col <- grep("Weight|MW|MolWt", names(num_cols), ignore.case = TRUE, value = TRUE)
          lp_col <- grep("LogP|MolLogP|ALogP", names(num_cols), ignore.case = TRUE, value = TRUE)
          if(length(mw_col) > 0 && length(lp_col) > 0) {
            pass_count <- sum(num_cols[[mw_col[1]]] <= 500 & num_cols[[lp_col[1]]] <= 5, na.rm = TRUE)
            ro5_display <- paste0(round((pass_count / nrow(num_cols)) * 100, 1), "%")
          }
        }, silent = TRUE)
        
        # 3. PCA Feature Drivers Safety Check
        feature_rows <- "<tr><td colspan='2'>PCA analysis not performed or failed</td></tr>"
        if(!is.null(pca_res) && !is.null(pca_res$rotation)) {
          try({
            loadings <- abs(pca_res$rotation[,1]) 
            top_10 <- sort(loadings, decreasing = TRUE)
            # Ensure we don't try to take more features than exist
            n_top <- min(10, length(top_10))
            top_10_features <- top_10[1:n_top]
            
            feature_rows <- paste0(
              "<tr><td>", names(top_10_features), "</td><td>", 
              round(top_10_features, 4), "</td></tr>", 
              collapse = ""
              
            )
            
            
            # Inside your report content generation logic:
            cat("## 📘 MDSLab Feature Glossary\n\n", file = report_file, append = TRUE)
            glossary <- get_mdslab_glossary()
            knitr::kable(glossary, format = "html") %>% 
              cat(file = report_file, append = TRUE)
          }, silent = TRUE)
        }
        
        
#============================================================
        # Define the ML utility description
        ml_utility_notes <- "
  <ul>
    <li><b>Standardized Inputs:</b> The exported CSV features have been centered and scaled (if selected), ensuring that high-magnitude descriptors (like Molecular Weight) do not mathematically overwhelm smaller descriptors (like LogP) during model training.</li>
    <li><b>Algorithmic Compatibility:</b> This data is formatted for immediate use in <i>Scikit-Learn (Python)</i> or <i>Caret/Tidymodels (R)</i>. It is specifically optimized for Random Forest, XGBoost, and Deep Learning architectures.</li>
    <li><b>Reduced Overfitting:</b> By utilizing the optimized feature set, users reduce the risk of the 'Curse of Dimensionality,' leading to models with better generalization on external test sets.</li>
  </ul>"
        
        qsar_benefits <- "
  <ul>
    <li><b>PCA (Principal Component Analysis):</b> Use these files to train models on 'orthogonal' features. PCA-based QSAR models are less prone to multi-collinearity issues, making the model coefficients more stable and interpretable.</li>
    <li><b>UMAP (Local Structure Preservation):</b> The UMAP coordinates are ideal for identifying 'Activity Cliffs.' If two molecules are close in UMAP space but have vastly different biological activities, they represent critical SAR (Structure-Activity Relationship) pivot points.</li>
    <li><b>Virtual Screening:</b> The visual mapping files help in selecting a 'diversity set'—ensuring that the molecules you choose for experimental validation cover the entire chemical space of your library.</li>
  </ul>"
#====================================================================================    
       

## Constuction of ML Report=======================================
        # 3. CONSTRUCT HTML
        report_html <- paste0(
          "<html><head><style>",
          "body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; padding: 40px; background-color: #f4f7f6; }",
          ".container { max-width: 900px; margin: auto; background: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }",
          "h1 { color: #2c3e50; border-bottom: 4px solid #18bc9c; padding-bottom: 15px; margin-bottom: 30px; }",
          "h3 { color: #2b5c8e; border-left: 5px solid #18bc9c; padding-left: 15px; margin-top: 35px; }",
          "table { width: 100%; border-collapse: collapse; margin: 25px 0; font-size: 0.9em; }",
          "th, td { padding: 15px; border: 1px solid #edf2f7; text-align: left; }",
          "th { background-color: #f8fafc; color: #2d3748; font-weight: 700; }",
          ".highlight { color: #18bc9c; font-weight: bold; font-size: 1.2em; }",
          ".stat-card { background: #f8fafc; border: 1px solid #e2e8f0; padding: 20px; border-radius: 10px; margin: 20px 0; }",
          "img { max-width: 100%; height: auto; border-radius: 10px; margin: 20px 0; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }",
          # Glossary Specific CSS
          ".glossary-table { width: 100%; border-collapse: collapse; margin: 20px 0; }",
          ".glossary-table th { background-color: #2c3e50; color: white; border-bottom: 3px solid #18bc9c; }",
          ".cat-badge { background-color: #18bc9c; color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; font-weight: bold; }",
          ".mds-id { color: #e74c3c; font-weight: bold; font-family: 'Courier New', monospace; }",
          ".mdslab-badge { background: #e74c3c; color: white; padding: 2px 5px; border-radius: 3px; font-size: 0.7rem; vertical-align: middle; }",
          "</style></head><body>",
          
          "<div class='container'>",
          "<h1>MDSLab ChemBridge-AI Tool Technical Report</h1>",
          "<h3>1. Execution Timeline</h3>",
          "<p><b>Process Started:</b> ", format(s$Start, '%H:%M:%S'), "</p>",
          "<p><b>Process Finished:</b> ", format(s$End, '%H:%M:%S'), "</p>",
          "<p><b>Total Runtime:</b> ", round(difftime(s$End, s$Start, units='secs'), 2), " seconds</p>",
          "<p><b>Dataset:</b> ", input$file$name, " | <b>Analysis Date:</b> ", format(Sys.time(), '%d %B %Y, %H:%M'), "</p>",
          
          "<div class='stat-card'>",
          "<h3>1. Feature Engineering Optimization</h3>",
          "<table>",
          "<tr><th>Metric</th><th>Analysis Result</th></tr>",
          "<tr><td>Molecules Successfully Processed</td><td>", s$Mols, "</td></tr>",
          "<tr><td>Total Initial Descriptors</td><td>", raw_count, "</td></tr>",
          "<tr><td>Total Initial FingerPrints</td><td>", s$fp_final_count, "</td></tr>",
          "<tr><td><b>ML-Ready Optimized Features</b></td><td class='highlight'>", final_count, "</td></tr>",
          "<tr><td>Feature Retention Rate</td><td>", retention_rate, "%</td></tr>",
          "<tr><td>Correlation Redundancy Cutoff</td><td>", input$corr_cutoff, "</td></tr>",
          "</table>",
          "</div>",
          
          "<h3>2. Dimensionality Reduction & Visual Mapping</h3>",
          "<p>The following plot represents the high-dimensional chemical space projected into two dimensions. This allows for the identification of structural outliers and chemical clusters.</p>",
          "<img src='", txt_plot, "'>",
          "<p><i>Note: PCA captures the global variance, while UMAP (available in app) preserves local structural similarities.</i></p>",
          
          "<h3>2.1 Feature Redundancy Profile</h3>",
          "<p>To ensure ML-readiness, highly collinear features were removed based on your cutoff (", input$corr_cutoff, "). This minimizes the <i>'Curse of Dimensionality'</i> and prevents model overfitting.</p>",
          "<p><i>Result: ", final_count, " independent features were retained out of ", raw_count, " initial candidates.</i></p>",
          
          "<h3>3. Calculation Engine Integrity</h3>",
          "<p>Descriptor generation was performed using a multi-engine architecture to ensure coverage of both graph-theoretical and physicochemical properties.</p>",
          "<ul>",
          "<li><b>MDSLab (Custom R Engine):</b> <span class='highlight'>", ifelse(is.null(s$MDSLab_count), 0, s$MDSLab_count), "</span> descriptors generated <span class='mdslab-badge'>NEW</span></li>",
          "<li><b>CDK (rcdk):</b> ", ifelse(is.null(s$CDK_count), 0, s$CDK_count), " descriptors generated.</li>",
          "<li><b>RDKit (Python):</b> ", ifelse(is.null(s$RDKit_count), 0, s$RDKit_count), " descriptors generated.</li>",
          "<li><b>Mordred (Python):</b> ", ifelse(is.null(s$Mordred_count), 0, s$Mordred_count), " descriptors generated.</li>",
          "<li><b>PaDEL (Python):</b> ", ifelse(is.null(s$PaDEL_count), 0, s$PaDEL_count), " descriptors generated.</li>",
          "<li><b>FingerPrints (Python):</b> ", ifelse(is.null(s$fp_final_count), 0, s$fp_final_count), " fingerprints generated.</li>",
          "</ul>",
 
          "<h3>3.1. Detailed Descriptor Glossary (MDSLab Standards)</h3>",
          "<p>Proprietary metrics and high-density feature definitions for the MDSLabChemBridge engine.</p>",
          "<table class='glossary-table'>",
          "  <thead>",
          "    <tr><th>Feature ID</th><th>Category</th><th>Scientific Description</th></tr>",
          "  </thead>",
          "  <tbody>",
          "    <tr><td><span class='mds-id'>MDS_Lability</span></td><td><span class='cat-badge'>Complexity</span></td><td>Phenyl + Methoxy flexibility markers; metabolic clearance indicators.</td></tr>",
          "    <tr><td><span class='mds-id'>MDS_Bio_Complexity</span></td><td><span class='cat-badge'>Complexity</span></td><td>(TPSA * Atom Count) / 100; measure of functional group density.</td></tr>",
          "    <tr><td><span class='mds-id'>MDS_Frag_[Name]</span></td><td><span class='cat-badge'>Fragment</span></td><td>Count of 12 specific SMARTS patterns (Hydroxyl, Phenyl, Amine, etc).</td></tr>",
          "    <tr><td><span class='mds-id'>MDS_PVSA_[1-50]</span></td><td><span class='cat-badge'>Surface Area</span></td><td>Vectorized Property-encoded Surface Area bins (Zone Analysis).</td></tr>",
          "    <tr><td><span class='mds-id'>MDS_Core_[1-275]</span></td><td><span class='cat-badge'>CDK Bridge</span></td><td>High-density features: Topological, Electronic, and Hybrid indices.</td></tr>",
          "  </tbody>",
          "</table>",
          
          "<h3>3.2. External Engine Reference</h3>",
          "<table class='glossary-table'>",
          "  <thead>",
          "    <tr><th>Engine Name</th><th>Type</th><th>Primary Use Case</th></tr>",
          "  </thead>",
          "  <tbody>",
          "    <tr><td><b>CDK (rcdk)</b></td><td>Java/Hybrid</td><td>High-density 2D/3D descriptors (unlocked 275+ set).</td></tr>",
          "    <tr><td><b>RDKit (Py)</b></td><td>C++/Python</td><td>Physicochemical properties and Lipinski compliance.</td></tr>",
          "    <tr><td><b>Mordred (Py)</b></td><td>Python</td><td>Exhaustive calculation of 2D and 3D molecular properties.</td></tr>",
          "    <tr><td><b>PaDEL (Py)</b></td><td>Java/Python</td><td>Standardized PubChem and Substructure fingerprints.</td></tr>",
          "  </tbody>",
          "</table>",
          
          "<h3>4. ML-Ready Optimized Features Methodology</h3>",
          "<p>The <b>ML-Ready Optimized Features</b> in the MDSLab ChemBridge-AI tool represent an automated feature engineering pipeline designed to transform raw chemical descriptors into a high-quality, non-redundant dataset. This process removes columns with missing values and filters 'near-zero variance' descriptors. The <b>Correlation Filter</b> removes redundant noise by pruning collinear features, reducing dimensionality and mitigating overfitting risks for subsequent machine learning tasks.</p>",
          
          "<h3>5. Expanded Physicochemical Profile</h3>",
          "<table>",
          "<tr><th>Property</th><th>Mean Value</th><th>Ideal Range (Lead-like)</th></tr>",
          "<tr><td>Molecular Weight</td><td>", mw_val, "</td><td>< 500 Da</td></tr>",
          "<tr><td>LogP (Lipophilicity)</td><td>", logp_val, "</td><td>< 5</td></tr>",
          "<tr><td>TPSA (Polarity)</td><td>", tpsa_val, "</td><td>< 140 Å²</td></tr>",
          "<tr><td>H-Bond Donors</td><td>", hbd_val, "</td><td>≤ 5</td></tr>",
          "<tr><td>H-Bond Acceptors (HBA)</td><td>", hba_val, "</td><td>≤ 10</td></tr>",
          "</table>",
          
          "<h3>6. Drug-Likeness & Quality Audit</h3>",
          "<div class='stat-card'>",
          "<ul>",
          "<li><b>Lipinski Compliance:</b> ", ro5_display, " of molecules meet basic Rule of 5 criteria.</li>",
          "<li><b>Missing Data Handling:</b> Pruning threshold set at ", 
          ifelse(is.null(input$corr_cutoff), "default", paste0(input$corr_cutoff * 100, "%")), 
          " redundancy.</li>",
          "<li><b>H-Bond Donors (HBD) Check:</b> ", 
          if(is.null(hbd_val) || hbd_val == "Not Available") {
            "<span style='color:orange;'>Not detected in current engine.</span>"
          } else {
            paste0("Dataset average: ", hbd_val)
          }, 
          "</li>",
          "</ul>",
          "</div>",
          
          "<h3>7. Guidelines for ML & QSAR Integration</h3>",
          "<p>The MDSLab ChemBridge-AI tool generates datasets specifically curated for high-performance Machine Learning. Below is a roadmap for utilizing these outputs in your research workflow:</p>",
          
          "<h4>7.1 Strategic Use of the Optimized Feature Set</h4>",
          "<p>The ML-Ready CSV output is the primary fuel for predictive modeling. Its benefits include:</p>",
          "<ul>",
          "<li><b>Dimensionality Management:</b> By removing low-variance and highly collinear descriptors, we mitigate the <i>'Curse of Dimensionality'</i>, which can otherwise lead to model over-fitting and poor generalizability.</li>",
          "<li><b>Standardized Scaling:</b> The features are pre-processed to ensure that descriptors with large numerical ranges (e.g., Molecular Weight) do not mathematically dominate those with smaller ranges (e.g., LogP), a critical step for Neural Networks and SVMs.</li>",
          "<li><b>Noise Reduction:</b> The pruning of redundant features improves the <i>Signal-to-Noise Ratio (SNR)</i>, allowing algorithms like Random Forest or XGBoost to identify true structural drivers of activity.</li>",
          "</ul>",
          
          "<div class='stat-card' style='border-left: 5px solid #2c3e50; background-color: #f0f4f8;'>",
          "<h4>7.2 Leveraging PCA & UMAP for QSAR Models</h4>",
          "<p>Beyond simple visualization, the dimensionality reduction files provide advanced analytical advantages:</p>",
          "<ul>",
          "<li><b>PCA-Based Modeling (PCR):</b> The PCA coordinates can be used as 'Principal Components' for <i>Principal Component Regression</i>. This is highly beneficial for QSAR models where descriptors are naturally inter-correlated.</li>",
          "<li><b>UMAP for Activity Cliff Detection:</b> UMAP excels at preserving local structural similarities. By overlaying biological activity on UMAP plots, researchers can identify 'Activity Cliffs' structural neighbors with vastly different bioactivities which are critical for SAR optimization.</li>",
          "<li><b>Applicability Domain (AD) Analysis:</b> Use the PCA/UMAP space to define the 'Applicability Domain.' If a new molecule falls outside the cluster boundaries of your training set in the projected space, the model’s prediction for that molecule should be treated with caution.</li>",
          "</ul>",
          "</div>",
          
          "<h4>7.3 Recommended Downstream Workflow</h4>",
          "<table>",
          "<tr><th>Phase</th><th>Action</th><th>Recommended Tools</th></tr>",
          "<tr><td>Data Loading</td><td>Import 'Optimized_Features.csv'</td><td>Python (Pandas) / R (Tidymodels)</td></tr>",
          "<tr><td>Model Selection</td><td>Train Ensemble Methods (XGBoost/RF)</td><td>Scikit-Learn / Caret</td></tr>",
          "<tr><td>Validation</td><td>Cross-Validation & External Test Sets</td><td>Y-Scrambling / Bootstrapping</td></tr>",
          "<tr><td>Interpretation</td><td>Feature Importance vs. Section 2.1 Drivers</td><td>SHAP Values / LIME</td></tr>",
          "</table>",
          "<h3>8. Citation & Acknowledgments</h3>",
          "<div class='stat-card' style='border-left: 5px solid #18bc9c; background-color: #f9fdfc;'>",
          "<p>If you use the <b>MDSLab ChemBridge-AI</b> tool in your research, please cite it to support the ongoing development of automated cheminformatics workflows:</p>",
          
          "<p style='padding: 15px; background: #ffffff; border: 1px dashed #ccd6d9; font-family: monospace; font-size: 0.9em;'>",
          "MDSLab ChemBridge-AI: An Automated Pipeline for Molecular Descriptor Engineering and ML-Ready Data Optimization. (2026). Available at: [Your Project URL/GitHub Link].",
          "</p>",
          
          "<h4>Underlying Libraries</h4>",
          "<p>This tool integrates several industry-standard libraries. Please consider citing the specific engines used in your analysis:</p>",
          "<ul style='font-size: 0.85em;'>",
          "<li><b>RDKit:</b> Landrum, G., et al. RDKit: Open-source cheminformatics. <a href='https://www.rdkit.org'>rdkit.org</a></li>",
          "<li><b>Mordred:</b> Moriwaki, H. et al. (2018). Mordred: a molecular descriptor calculator. <i>J. Cheminform.</i> 10, 4.</li>",
          "<li><b>CDK:</b> Willighagen, E. L. et al. (2017). The Chemistry Development Kit (CDK) v2.0. <i>J. Cheminform.</i> 9, 33.</li>",
          "</ul>",
          "</div>",

          "<p style='font-size: 0.8em; color: #7f8c8d; text-align: center; margin-top: 30px;'>",
          "Report generated by MDSLab ChemBridge-AI &copy; 2026</p>",
          
          "<p style='background: #e8f8f5; padding: 10px; border-radius: 5px; border: 1px solid #18bc9c;'>",
          "<b>Researcher Note:</b> For publication-quality QSAR studies, it is recommended to report the <i>Feature Retention Rate</i> (Section 1) to document the transparency of your data cleaning protocol.</p>",
          "<p style='margin-top:50px; font-size: 0.8rem; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 20px;'>",
          "This document is an automated output of the MDSLab Unified Pipeline. Data is validated for ML-Readiness.</p>",
          "</div></body></html>"
        )
        writeLines(report_html, file)
      }
    )
    
    # --- 📜 LOG FILE (Full Detail Restored) ---
    output$down_log <- downloadHandler(
      filename = function() paste0("Calculation_Log_", Sys.Date(), ".txt"),
      content = function(file) {
        # use isolate to grab the data safely
        s <- isolate(log_info())
        
        duration <- difftime(s$End, s$Start, units = "auto")
        
        # Helper to handle NULL values if an engine wasn't run
        check_val <- function(x) if(is.null(x) || is.na(x)) "0 (Not Selected)" else x
        
        # Header & Basic Info
        lines <- c(
          "=======================================",
          "      MDSLab ChemBridge-AI LOG",
          "=======================================",
          paste("Generated on: ", Sys.time()),
          paste("R Version:    ", R.version.string),
          "------------------------------------------------------",
          "",
          "1. EXECUTION TIMELINE---------------------------------",
          paste("  Job Started:      ", format(s$Start, "%Y-%m-%d %H:%M:%S")),
          paste("  Job Finished:     ", format(s$End, "%Y-%m-%d %H:%M:%S")),
          paste("  Total Duration:   ", round(duration, 2), units(duration)),
          "",
          "2. JOB SUMMARY",
          paste("  Total Compounds:      ", check_val(s$Mols)),
          paste("  Execution Status:     Complete"),
          "",
          "3. DESCRIPTOR BREAKDOWN-------------------------------",
          paste("  MDSLab (Custom):      ", check_val(s$MDSLab_count)), # Added MDSLab
          paste("  CDK:                  ", check_val(s$CDK_count)),
          paste("  RDKit:                ", check_val(s$RDKit_count)),
          paste("  Mordred:              ", check_val(s$Mordred_count)),
          paste("  PaDEL:                ", check_val(s$PaDEL_count)),
          paste("  Fingerprint Bits:     ", check_val(s$fp_final_count)),
          "",

          "4. DIMENSION SUMMARY-----------------------------------",
          paste("  1D Descriptors:       ", s$count_1D),
          paste("  2D Descriptors:       ", s$count_2D),
          paste("  3D Descriptors:       ", s$count_3D),
          paste("  Fingerprint Bits:     ", check_val(s$fp_final_count)),
          "",
          "5. INPUT METADATA--------------------------------------",
          paste("  File Name:            ", s$filename),
          paste("  3D Optimization:      ", ifelse(input$filetype == "sdf", "Enabled (Direct SDF)", "Disabled (SMILES Embedding)")),
          "",
          "6. INPUT METADATA--------------------------------------",
          paste("  Input Source:         ", ifelse(is.null(s$filename), "Manual Upload", s$filename)),
          paste("  Prep Mode:            ", ifelse(is.null(s$prep_mode), "Standard", s$prep_mode)),
          "",
          "7. COMPUTATIONAL ENVIRONMENT---------------------------",
          paste("  Platform:             ", sessionInfo()$platform),
          paste("  Running via:          MDSLab ChemBridge-AI Engine"),
          paste("  Platform:             ", sessionInfo()$platform),
          paste("  Python Version:       ", reticulate::py_config()$version),
          paste("  Java Version:         ", system("java -version", intern = TRUE)[1]), 
          paste("  Logical CPU Cores:    ", parallel::detectCores()),
          paste("  Engine Authority:     MDSLab ChemBridge-AI Engine v1.0"),
          "",
          "8. MDSLAB PROPRIETARY ANALYSIS-------------------------", # New Audit Section
          paste("  Feature Density:      ", check_val(s$MDSLab_count), " Custom Descriptors"),
          paste("  Integration Level:    R Package MDSLabChemBridge Bridge"),
          "---------------------------------------",
          "End of Log."
        )
        
        writeLines(lines, file)
      }
    )
    
}
  shinyApp(ui, server)
}

